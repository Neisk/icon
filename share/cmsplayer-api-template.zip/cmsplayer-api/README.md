# CMSPlayer 静态接口仓库

这是一个可直接用于 CMSPlayer 的接口 JSON 仓库。  
可部署到 Cloudflare Pages 或 GitHub Pages，在 CMSPlayer 设置接口地址即可使用。

## 使用方法
1. 将仓库部署到 Cloudflare Pages 或 GitHub Pages。  
2. 获取 URL，例如：
   https://cmsplayer.nisc.fun/api.json
3. 打开 CMSPlayer → 设置接口 → 填入此 URL 即可。
